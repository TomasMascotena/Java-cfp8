/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase14;

import java.util.Scanner;

/**
 *
 * @author Alumno15
 */
public class Clase14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner teclado = new Scanner(System.in);
        /*
        1) Una tienda ofrece un descuento del 15% sobre el total de la compra durante
        el mes de octubre. Dado un mes y un importe, calcular cu�l es la cantidad que
        se debe cobrar al cliente.
        */
//        String mes;
//        float monto;
//        System.out.println("Bienvenido, ingresar en que mes esta realizando la compra");
//        mes = teclado.nextLine().toLowerCase();
//        System.out.println("Ingrese el monto total de la compra");
//        monto= teclado.nextFloat();
//        switch (mes){
//            case "enero" : System.out.println("El monto total es de: $" +monto); break;
//            case "febrero" : System.out.println("El monto total es de: $" +monto); break;
//            case "marzo" :System.out.println("El monto total es de: $" +monto); break;
//            case "abril" :System.out.println("El monto total es de: $" +monto); break;
//            case "mayo" :System.out.println("El monto total es de: $" +monto); break;
//            case "junio" :System.out.println("El monto total es de: $" +monto); break;
//            case "julio" :System.out.println("El monto total es de: $" +monto); break;
//            case "agosto" :System.out.println("El monto total es de: $" +monto); break;
//            case "septiembre" :System.out.println("El monto total es de: $" +monto); break;
//            case "octubre" : System.out.println("Octubre tiene un 15% de descuento. El monto a pagar es: $" + monto*0.85); break;
//            case "noviembre" :System.out.println("El monto total es de: $" +monto); break;
//            case "diciembre" :System.out.println("El monto total es de: $" +monto); break;
//            default: System.out.println("Error en mes ingresado"); System.exit(0);
//        }      
        /*
        2) Crear un programa que pida al usuario un n�mero y un s�mbolo, y dibuje un
        cuadrado usando ese s�mbolo. El cuadrado tendr� el tama�o que ha indicado
        el usuario. Por ejemplo, si el usuario introduce 4 como tama�o y * como
        s�mbolo, deber� escribirse algo como: 
        */
        
//        System.out.println("Por favor ingrese un numero");
//        int numero = teclado.nextInt();
//        teclado.nextLine();
//        System.out.println("Ingrese un simbolo");
//        char simbolo = teclado.next().charAt(0);
//        
//        for (int i = 0; i < numero; i++) {
//            for (int j = 0; j < numero; j++) {
//                System.out.print(simbolo);
//            }
//            System.out.println("");
//        }
        
        /*
        3) Se pide representar el algoritmo que nos calcule la suma de los N primeros
        n�meros naturales. N se leer� por teclado. Ejemplo, si ingresamos 4, hacer:
        1+2+3+4 = 10
        */
//        int cantidadNumeros;
//        int total =0;
//        System.out.println("Bienvenido. Por favor ingrese cuantos numeros desea sumar");
//        cantidadNumeros = teclado.nextInt();
//        for (int i = 1; i <= cantidadNumeros; i++) {
//            System.out.print(i);
//            total += i;      
//            if (i<cantidadNumeros){
//                System.out.print(" + ");
//            }
//        }
//        System.out.println(" = " + total);

        /*
        4) Crear un programa que visualice la cuenta de los n�meros que son m�ltiplos
        de 2 o de 3 que hay entre 1 y 100
        */
//        int contador = 0;
//        for (int i = 0; i <= 100; i++) {
//            int restoDos = i%2;
//            int restoTres = i%3;
//            if (restoDos==0 || restoTres==0) contador++;}
//        System.out.println("La cantidad de numeros que son resto de 2 o 3 desde 1 a 100 es igual a " +contador);
        
        /*
        5) Desarrollar un programa que permita ingresar un n�mero N. Acto seguido,
        permitir ingresar N n�meros. La computadora muestra cu�l fue el mayor y en qu�
        orden apareci�. Ejemplo: Se ingresa 5, luego 4 8 6 7 5, la computadora
        muestra: "El mayor es el 8 en la 2� posici�n"
        */
        System.out.println("Ingrese un numero");
        int numero = teclado.nextInt();
        int numeroMayor = Integer.MIN_VALUE;
        int posicion;
        for (int i=1; i <= numero; i++);{
        System.out.println("Ingrese el " + i + "� numero");
        int numeroIngresado = teclado.nextInt();
        
        if (numeroIngresado>numeroMayor){
            numeroMayor = numeroIngresado;
            posicion = i;
        }
    }
        System.out.println("El mayor numero fue el " + numeroMayor);
        System.out.println("Que se encontro en la posicion " + posicion);
        
        
        
        
//        int repeticiones;
//        int comparacion;
//        int mayorNumero = 0;
//        System.out.println("Bienvenido. Digite cuantos numeros desea comparar?");
//        repeticiones = teclado.nextInt();
//        for (int i = 1; i <= repeticiones; i++) {
//            System.out.println("Digite numero a comparar:");
//            comparacion = teclado.nextInt();
//            if (comparacion > mayorNumero) {
//                mayorNumero = comparacion;
//            }
//        }
//        System.out.println("De los numeros digitados, el mayor es: " + mayorNumero);
        
        /*
        6) Desarrollar un programa que permita ingresar un n�mero natural. La
        computadora muestra el factorial del n�mero. Ejemplo: Se ingresa 5, la
        computadora muestra: 120. 
        */
//        int factorial;
//        int multiplicador = 1;
//        int sumativa = 0;
//        System.out.println("Ingrese el numero del cual desea saber el factorial");
//        factorial = teclado.nextInt();
//        for (int i = factorial; i > 1; i--) {
//            if (i == factorial) {
//                multiplicador = i;
//            }
//            sumativa += i*multiplicador;
//        }
//        System.out.println("El factorial de " +factorial+ " es igual a: " + sumativa);
       
//error
        
        /*
        7) Crear un algoritmo (y su correspondiente diagrama de flujo) que lea n�meros
        enteros hasta teclear 0, y nos muestre el m�ximo, el m�nimo (sin considerar el
        0) y la media (promedio) de todos ellos.
        */
//        int vueltas = 0;
//        int promedio = 0;
//        int numeroMaximo;
//        int numeroMinimo;
//        int eleccion;
//        System.out.println("Bienvenido. El sistema compara y promedia numeros hasta que presiones 0");
//        System.out.println("Digite el primer valor:");
//        eleccion = teclado.nextInt();
//        numeroMaximo= eleccion;
//        numeroMinimo= eleccion;
//        while (eleccion != 0){
//            vueltas ++;
//            System.out.println("Elija el proximo valor a comparar y promediar: ");
//            promedio += eleccion;
//            eleccion = teclado.nextInt();
//            if (eleccion<numeroMinimo && eleccion!=0) numeroMinimo=eleccion;
//            if (eleccion>numeroMaximo) numeroMaximo=eleccion;
//        }
//        System.out.println("El numero minimo es: " + numeroMinimo);
//        System.out.println("El numero maximo es: " + numeroMaximo);
//        System.out.println("El promedio de todos los numeros es: " + promedio/vueltas);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
