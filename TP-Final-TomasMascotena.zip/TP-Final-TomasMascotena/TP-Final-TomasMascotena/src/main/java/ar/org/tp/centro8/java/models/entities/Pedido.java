package ar.org.tp.centro8.java.models.entities;

import java.time.LocalDateTime;

import ar.org.tp.centro8.java.models.enums.Estado;
import ar.org.tp.centro8.java.models.enums.TipoPedido;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pedido {
    private int idPedido;
    private TipoPedido tipoPedido;
    private Estado estado;
    private Boolean estaPagado = false;
    private Double montoTotal;
    private LocalDateTime fechaHoraCreacion;
    private LocalDateTime fechaHoraEntrega;
    private int numeroMesa;
    private int idResponsable;
}