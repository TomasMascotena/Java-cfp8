package ar.org.tp.centro8.java.models.enums;

public enum TipoPedido {
    EN_MESA, PARA_LLEVAR, DELIVERY;
}
