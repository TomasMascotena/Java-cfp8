package ar.org.tp.centro8.java.models.entities;

import ar.org.tp.centro8.java.models.enums.Rol;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Persona {
    private int idPersona;
    private String nombre;
    private String apellido;
    private Rol rol;
}
