package ar.org.tp.centro8.java.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.tp.centro8.java.models.entities.DetallePedido;


public interface I_DetallePedidoRepository {
    void create(DetallePedido detallePedido) throws SQLException;
    DetallePedido findByIdPedidoAndIdProducto(int idPedido, int idProducto) throws SQLException;
    List<DetallePedido> findAll() throws SQLException;
    int update(DetallePedido detallePedido) throws SQLException;
    int delete(int idPedido, int idProducto) throws SQLException;
    List<DetallePedido> findByIdPedido(int idPedido) throws SQLException;
    List<DetallePedido> findByIdProducto(int idProducto) throws SQLException;
}
