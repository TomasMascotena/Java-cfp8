package ar.org.tp.centro8.java.models.enums;

public enum Estado {
    EN_PROCESO, ENTREGADO;
}
