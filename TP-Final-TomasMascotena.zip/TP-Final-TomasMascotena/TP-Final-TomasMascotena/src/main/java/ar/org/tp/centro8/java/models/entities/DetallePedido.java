package ar.org.tp.centro8.java.models.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetallePedido {
    private int idPedido;
    private int idProducto;
    private int cantidad;
    private double precioUnitario; 
}