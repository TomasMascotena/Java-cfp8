package ar.org.tp.centro8.java.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.tp.centro8.java.models.entities.Persona;
import ar.org.tp.centro8.java.models.enums.Rol;


public interface I_PersonaRepository {
    void create(Persona persona) throws SQLException;
    Persona findById(int idPersona) throws SQLException;
    List<Persona> findAll() throws SQLException;
    int update(Persona persona) throws SQLException;
    int delete(int idPersona) throws SQLException;
    List<Persona> findByRol(Rol rol) throws SQLException;
    List<Persona> findByNombre(String nombre) throws SQLException;
    List<Persona> findByApellido(String apellido) throws SQLException;
}
