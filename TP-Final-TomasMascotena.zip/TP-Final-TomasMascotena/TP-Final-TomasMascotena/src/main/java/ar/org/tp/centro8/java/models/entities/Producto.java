package ar.org.tp.centro8.java.models.entities;

import ar.org.tp.centro8.java.models.enums.Categoria;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Producto {
    private int idProducto;
    private String nombre;
    private double precio;
    private Categoria categoria;
}