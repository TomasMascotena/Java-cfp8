package ar.org.tp.centro8.java.models.enums;

public enum Categoria {
    BEBIDAS_FRIAS, BEBIDAS_CALIENTES, COMIDAS , PASTELERIA;}
