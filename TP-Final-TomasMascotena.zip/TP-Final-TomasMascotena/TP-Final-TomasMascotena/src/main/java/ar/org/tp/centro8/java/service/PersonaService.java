package ar.org.tp.centro8.java.service;

import org.springframework.stereotype.Service;

import ar.org.tp.centro8.java.models.repositories.interfaces.I_PersonaRepository;

@Service
public class PersonaService {
    private final I_PersonaRepository personaRepository;

    public PersonaService(I_PersonaRepository personaRepository) {
        this.personaRepository = personaRepository;
    }



}
