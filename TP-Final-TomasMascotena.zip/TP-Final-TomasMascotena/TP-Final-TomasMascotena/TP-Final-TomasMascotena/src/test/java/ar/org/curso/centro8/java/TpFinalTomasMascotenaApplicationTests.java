package ar.org.curso.centro8.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpFinalTomasMascotenaApplicationTests {

	@Test
	void contextLoads() {
	}

}
