package ar.org.curso.centro8.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.curso.centro8.java.entities.DetallePedido;

public interface I_DetallePedidoRepository {
    void create(DetallePedido detallePedido) throws SQLException;
    /*
     * DetallePedido no contiene atributo de identificacion ya que funciona como
     * conector, imposibilitando realizar un findById.
     */ 
    List<DetallePedido> findByAll() throws SQLException;
    int update(DetallePedido detallePedido) throws SQLException;
    int delete(int idPedido, int idProducto) throws SQLException;
    List<DetallePedido> findByIdPedido(int idPedido) throws SQLException;
}
