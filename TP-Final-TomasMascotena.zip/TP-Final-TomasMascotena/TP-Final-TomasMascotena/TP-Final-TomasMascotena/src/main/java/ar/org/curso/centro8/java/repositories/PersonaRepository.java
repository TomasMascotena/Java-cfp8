package ar.org.curso.centro8.java.repositories;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.curso.centro8.java.entities.Persona;
import ar.org.curso.centro8.java.enums.Rol;
import ar.org.curso.centro8.java.repositories.interfaces.I_PersonaRepository;

@Repository
public class PersonaRepository implements I_PersonaRepository{

    private final DataSource dataSource;

    public static final String SQL_CREATE = "INSERT INTO personas (nombre, apellido, rol) values (?,?,?)";
    public static final String SQL_FIND_BY_ID = "SELECT * FROM personas WHERE id_persona=?";
    public static final String SQL_FIND_ALL = "SELECT * FROM personas";
    public static final String SQL_UPDATE = "UPDATE personas SET nombre=?, apellido=?, rol=? where id_persona=?";
    public static final String SQL_DELETE = "DELETE FROM personas WHERE id_persona=?";
    public static final String SQL_FIND_BY_CATEGORIA = "SELECT * FROM personas WHERE categoria=?";

    public PersonaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Persona persona) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'create'");
    }

    @Override
    public Persona findById(int idPersona) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Persona> findAll() throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public int update(Persona persona) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public int delete(int idPersona) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public List<Persona> findByRol(Rol rol) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByRol'");
    }


}
