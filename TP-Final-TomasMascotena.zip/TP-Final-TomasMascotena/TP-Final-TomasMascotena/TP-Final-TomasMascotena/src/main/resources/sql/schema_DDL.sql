DROP TABLE IF EXISTS personas;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS detalle_pedido;

CREATE TABLE personas (
    id_persona int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    rol enum('mozo', 'cajero') not null
);

CREATE TABLE productos (
    id_producto int auto_increment primary key,
    nombre varchar(100) not null,
    precio decimal(10, 2) not null,
    categoria enum('bebidas_frias', 'bebidas_calientes', 'comidas', 'pasteleria') not null
);

CREATE TABLE pedidos (
    id_pedido int auto_increment primary key,
    tipo_pedido enum('en_mesa', 'para_llevar', 'delivery') not null,
    estado enum('en_proceso', 'entregado') not null,
    esta_pagado boolean not null default false,
    monto_total decimal(10, 2) not null,
    fecha_hora_creacion datetime not null default current_timestamp,
    fecha_hora_entrega datetime null,
    numero_mesa int null,
    id_responsable int not null,
    foreign key (id_responsable) references personas(id_persona)
);

CREATE TABLE detalle_pedido (
    id_pedido int not null,
    id_producto int not null,
    cantidad int not null,
    precio_unitario decimal(10, 2) not null,
    primary key (id_pedido, id_producto),
    foreign key (id_pedido) references pedidos(id_pedido),
    foreign key (id_producto) references productos(id_producto)
);