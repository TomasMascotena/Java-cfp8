package ar.org.curso.centro8.java.repositories;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.curso.centro8.java.entities.Pedido;
import ar.org.curso.centro8.java.enums.TipoPedido;
import ar.org.curso.centro8.java.repositories.interfaces.I_PedidoRepository;

@Repository
public class PedidoRepository implements I_PedidoRepository{
    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO pedidos (tipo_pedido, estado, esta_pagado, turno) VALUES (?,?,?,?)"; // ME QUEDE ACA
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM pedidos WHERE id=?";
    private static final String SQL_FIND_ALL = 
        "SELECT * FROM pedidos";
    private static final String SQL_UPDATE =
        "UPDATE pedidos SET titulo=?, profesor=?, dia=?, turno=?, activo=? WHERE id=?";
    private static final String SQL_DELETE = 
        "DELETE FROM pedidos WHERE id=?";
    private static final String SQL_FIND_BY_DIA_TURNO = 
        "SELECT * FROM pedidos WHERE dia=? and turno=?";
    
    public CursoDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    @Override
    public void create(Pedido pedido) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'create'");
    }

    @Override
    public Pedido findById(int idPedido) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Pedido> findAll() throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public int update(Pedido pedido) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public int delete(int idPedido) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public List<Pedido> findByTipoPedido(TipoPedido tipoPedido) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByTipoPedido'");
    }


}
