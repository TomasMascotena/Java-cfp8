package ar.org.curso.centro8.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.curso.centro8.java.entities.Producto;
import ar.org.curso.centro8.java.enums.Categoria;

public interface I_ProductoRepository {
    void create(Producto producto) throws SQLException;
    Producto findById(int idProducto) throws SQLException;
    List<Producto> findAll() throws SQLException;
    int update(Producto producto) throws SQLException;
    int delete(int idProducto) throws SQLException;
    List<Producto> findByCategoria(Categoria categoria) throws SQLException;
}