package ar.org.curso.centro8.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.curso.centro8.java.entities.Producto;
import ar.org.curso.centro8.java.enums.Categoria;
import ar.org.curso.centro8.java.repositories.interfaces.I_ProductoRepository;

@Repository
public class ProductoRepository implements I_ProductoRepository{

    private final DataSource dataSource;

    private static final String SQL_CREATE = "INSERT INTO productos (nombre, precio, categoria) VALUES (?,?,?)";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM productos WHERE id_producto=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM productos";
    private static final String SQL_UPDATE = "UPDATE productos SET nombre=?, precio=?, categoria=? WHERE id_producto=?";
    private static final String SQL_DELETE = "DELETE FROM productos WHERE id_producto=?";
    private static final String SQL_FIND_BY_CATEGORIA = "SELECT * FROM productos WHERE categoria=?";
    
    public ProductoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Producto producto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, producto.getNombre());
            ps.setDouble(2, producto.getPrecio());
            ps.setString(3, producto.getCategoria().name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    producto.setIdProducto(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Producto findById(int idProducto) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Producto> findAll() throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public int update(Producto producto) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public int delete(int idProducto) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public List<Producto> findByCategoria(Categoria categoria) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByCategoria'");
    }

}
