package ar.org.curso.centro8.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpFinalTomasMascotenaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpFinalTomasMascotenaApplication.class, args);
	}

}
