package ar.org.curso.centro8.java.enums;

public enum Categoria {
    BEBIDA_FRIA, BEBIDA_CALIENTE, COMIDAS , PASTELERIA;}
