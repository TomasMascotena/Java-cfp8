INSERT INTO personas(nombre, apellido, rol) VALUES
('Ruben','Gonzales','cajero'),
('Maria','Perez','cajero'),
('Cristian','Ladino','mozo'),
('Julia','Santos','mozo');

INSERT INTO productos (nombre, precio, categoria) VALUES
('Café con leche', 1200.00, 'bebidas_calientes'),
('Café espresso', 1050.00, 'bebidas_calientes'),
('Capuchino', 1250.00, 'bebidas_calientes'),
('Submarino', 1350.00, 'bebidas_calientes'),
('Té', 950.00, 'bebidas_calientes');

INSERT INTO productos (nombre, precio, categoria) VALUES
('Agua mineral', 800.00, 'bebidas_frias'),
('Gaseosa 350ml', 1000.00, 'bebidas_frias'),
('Licuado de banana', 1500.00, 'bebidas_frias'),
('Jugo exprimido de naranja', 1600.00, 'bebidas_frias'),
('Té frío con limón', 1300.00, 'bebidas_frias');

INSERT INTO productos (nombre, precio, categoria) VALUES
('Tostado de jamón y queso', 2900.00, 'comidas'),
('Empanada de carne', 1200.00, 'comidas'),
('Empanada de jamón y queso', 1200.00, 'comidas'),
('Milanesa con papas', 11000.00, 'comidas'),
('Tarta de verduras', 10000.00, 'comidas'),
('Sandwich de pollo caliente', 18000.00, 'comidas'),
('Fideos con tuco', 9000.00, 'comidas'),
('Sopa del día', 7500.00, 'comidas'),
('Hamburguesa completa', 15000.00, 'comidas'),
('Omelette de queso', 2000.00, 'comidas');

INSERT INTO productos (nombre, precio, categoria) VALUES
('Medialuna de manteca', 600.00, 'pasteleria'),
('Medialuna de grasa', 600.00, 'pasteleria'),
('Torta de chocolate', 4500.00, 'pasteleria'),
('Torta de ricota', 1900.00, 'pasteleria'),
('Tarta de frutilla', 4100.00, 'pasteleria'),
('Budín de limón', 3000.00, 'pasteleria'),
('Brownie', 2400.00, 'pasteleria'),
('Alfajor de maicena', 1000.00, 'pasteleria'),
('Muffin de arándanos', 2400.00, 'pasteleria');

INSERT INTO pedidos (tipo_pedido, estado, esta_pagado, monto_total, fecha_hora_creacion, fecha_hora_entrega, numero_mesa, id_responsable) VALUES
('en_mesa', 'en_proceso', FALSE, 10350.00, '2025-06-15 09:15:00', NULL, 1, 3),
('en_mesa', 'entregado', FALSE, 7000.00, '2025-06-15 10:05:00', '2025-06-15 10:40:00', 2, 3),
('para_llevar', 'entregado', FALSE, 3200.00, '2025-06-15 10:30:00', '2025-06-15 11:00:00', NULL, 1),
('delivery', 'en_proceso', TRUE, 4600.00, '2025-06-15 11:15:00', NULL, NULL, 1),
('en_mesa', 'entregado', TRUE, 15000.00, '2025-06-15 12:45:00', '2025-06-15 13:30:00', 3, 3),
('para_llevar', 'en_proceso', TRUE, 2900.00, '2025-06-15 13:10:00', NULL, NULL, 1),
('en_mesa', 'entregado', FALSE, 7300.00, '2025-06-15 14:20:00', '2025-06-15 15:00:00', 4, 4),
('delivery', 'entregado', TRUE, 6200.00, '2025-06-15 15:05:00', '2025-06-15 15:50:00', NULL, 2),
('en_mesa', 'en_proceso', FALSE, 8100.00, '2025-06-15 15:45:00', NULL, 5, 4),
('para_llevar', 'en_proceso', FALSE, 4100.00, '2025-06-15 16:10:00', NULL, NULL, 2),
('en_mesa', 'entregado', TRUE, 16200.00, '2025-06-15 17:25:00', '2025-06-15 18:00:00', 6, 4),
('delivery', 'en_proceso', TRUE, 6750.00, '2025-06-15 17:45:00', NULL, NULL, 2); 

-- Pedido 1 - $10.350
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(1, 3, 2, 1250.00),         -- Capuchino
(1, 11, 2, 2900.00),        -- Tostado de jamón y queso
(1, 2, 1, 1050.00),         -- Café espresso
(1, 7, 1, 1000.00);         -- Gaseosa 350ml

-- Pedido 2 - $7.000
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(2, 1, 1, 1200.00),         -- Café con leche
(2, 11, 2, 2900.00);        -- Tostado de jamón y queso

-- Pedido 3 - $3.200
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(3, 12, 2, 1200.00),        -- Empanada de carne
(3, 6, 1, 800.00);          -- Agua mineral

-- Pedido 4 - $4.600
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(4, 1, 1, 1200.00),         -- Café con leche
(4, 27, 1, 2400.00),        -- Brownie
(4, 28, 1, 1000.00);        -- Alfajor de maicena

-- Pedido 5 - $15.000
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(5, 19, 1, 15000.00);       -- Hamburguesa completa

-- Pedido 6 - $2.900
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(6, 11, 1, 2900.00);        -- Tostado de jamón y queso

-- Pedido 7 - $7.300
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(7, 13, 2, 1200.00),        -- Empanada de jamón y queso
(7, 1, 1, 1200.00),         -- Café con leche
(7, 10, 1, 1300.00),        -- Té frío con limón
(7, 27, 1, 2400.00);        -- Brownie

-- Pedido 8 - $6.200
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(8, 3, 1, 1250.00),         -- Capuchino
(8, 5, 1, 950.00),          -- Té
(8, 26, 1, 3000.00),        -- Budín de limón
(8, 28, 1, 1000.00);        -- Alfajor de maicena

-- Pedido 9 - $8.100
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(9, 3, 1, 1250.00),         -- Capuchino
(9, 27, 1, 2400.00),        -- Brownie
(9, 12, 1, 1200.00),        -- Empanada de carne
(9, 10, 1, 1300.00),        -- Té frío con limón
(9, 28, 1, 1000.00),        -- Alfajor de maicena
(9, 5, 1, 950.00);          -- Té

-- Pedido 10 - $4.100
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(10, 25, 1, 4100.00);       -- Tarta de frutilla

-- Pedido 11 - $16.200
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(11, 19, 1, 15000.00),      -- Hamburguesa completa
(11, 12, 1, 1200.00);   	-- Empanada de jamón y queso

-- Pedido 12 - $6750
INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
(12, 1, 1, 1200.00),        -- Café con leche
(12, 27, 1, 2400.00),       -- Brownie
(12, 28, 1, 1000.00),       -- Alfajor de maicena
(12, 5, 1, 950.00),         -- Té
(12, 11, 1, 1200.00); 		-- Empanada de carne