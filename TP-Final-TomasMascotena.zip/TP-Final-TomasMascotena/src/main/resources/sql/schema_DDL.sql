DROP TABLE IF EXISTS detalle_pedido;
DROP TABLE IF EXISTS pedidos;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS personas;



CREATE TABLE personas (
    id_persona int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    rol enum('MOZO', 'CAJERO') not null
);

CREATE TABLE productos (
    id_producto int auto_increment primary key,
    nombre varchar(100) not null,
    precio decimal(10, 2) not null,
    categoria enum('BEBIDAS_FRIAS', 'BEBIDAS_CALIENTES', 'COMIDAS', 'PASTELERIA') not null
);

CREATE TABLE pedidos (
    id_pedido int auto_increment primary key,
    tipo_pedido enum('EN_MESA', 'PARA_LLEVAR', 'DELIVERY') not null,
    estado enum('EN_PROCESO', 'ENTREGADO') not null,
    esta_pagado boolean not null default false,
    monto_total decimal(10, 2) not null,
    fecha_hora_creacion datetime not null default current_timestamp,
    fecha_hora_entrega datetime,
    numero_mesa int,
    id_responsable int not null,
    foreign key (id_responsable) references personas(id_persona)
);

CREATE TABLE detalle_pedido (
    id_pedido int not null,
    id_producto int not null,
    cantidad int not null,
    precio_unitario decimal(10, 2) not null,
    primary key (id_pedido, id_producto),
    foreign key (id_pedido) references pedidos(id_pedido),
    foreign key (id_producto) references productos(id_producto)
);