package ar.org.curso.centro8.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.curso.centro8.java.entities.Pedido;
import ar.org.curso.centro8.java.enums.Estado;
import ar.org.curso.centro8.java.enums.TipoPedido;
import ar.org.curso.centro8.java.repositories.interfaces.I_PedidoRepository;

@Repository
public class PedidoRepository implements I_PedidoRepository{
    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO pedidos (tipo_pedido, estado, esta_pagado, monto_total, fecha_hora_creacion, fecha_hora_entrega, numero_mesa, id_responsable) VALUES (?,?,?,?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM pedidos WHERE id_pedido=?";
    private static final String SQL_FIND_ALL = 
        "SELECT * FROM pedidos";
    private static final String SQL_UPDATE =
        "UPDATE pedidos SET tipo_pedido=?, estado=?, esta_pagado=?, monto_total=?, fecha_hora_creacion=?, fecha_hora_entrega=?, numero_mesa=?, id_responsable=? WHERE id_pedido=?";
    private static final String SQL_DELETE = 
        "DELETE FROM pedidos WHERE id_pedido=?";
    private static final String SQL_FIND_BY_TIPO_PEDIDO = 
        "SELECT * FROM pedidos WHERE tipo_pedido=?";
    
    public PedidoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    
    @Override
    public void create(Pedido pedido) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, pedido.getTipoPedido().name());
            ps.setString(2, pedido.getEstado().name());
            ps.setBoolean(3, pedido.getEstaPagado());
            ps.setDouble(4, pedido.getMontoTotal());
            ps.setObject(5, pedido.getFechaHoraCreacion());
            ps.setObject(6, pedido.getFechaHoraEntrega());
            ps.setInt(7, pedido.getNumeroMesa());
            ps.setInt(8, pedido.getIdResponsable());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    pedido.setIdPedido(keys.getInt(1));
                }
            }
        }    
    }

    @Override
    public Pedido findById(int idPedido) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Pedido> findAll() throws SQLException {
        List<Pedido> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
                    while(rs.next()){
                        lista.add(mapRow(rs));
                    }
        }
        return lista;
    }


    @Override
    public int update(Pedido pedido) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)){
            ps.setString(1, pedido.getTipoPedido().name());
            ps.setString(2, pedido.getEstado().name());
            ps.setBoolean(3, pedido.getEstaPagado());
            ps.setDouble(4, pedido.getMontoTotal());
            ps.setObject(5, pedido.getFechaHoraCreacion());
            ps.setObject(6, pedido.getFechaHoraEntrega());
            ps.setInt(7, pedido.getNumeroMesa());
            ps.setInt(8, pedido.getIdResponsable());
            ps.setInt(9, pedido.getIdPedido());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int idPedido) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idPedido);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Pedido> findByTipoPedido(TipoPedido tipoPedido) throws SQLException {
        List<Pedido> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_TIPO_PEDIDO)) {
            ps.setString(1, tipoPedido.name());
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Pedido mapRow(ResultSet rs) throws SQLException{
        Pedido pedido = new Pedido();
        pedido.setIdPedido(rs.getInt("id_pedido"));
        pedido.setTipoPedido(TipoPedido.valueOf(rs.getString("tipo_pedido")));
        pedido.setEstado(Estado.valueOf(rs.getString("estado")));
        pedido.setEstaPagado(rs.getBoolean("esta_pagado"));
        pedido.setMontoTotal(rs.getDouble("monto_total"));
        pedido.setFechaHoraCreacion(rs.getObject("fecha_hora_creacion", LocalDateTime.class));
        pedido.setFechaHoraEntrega(rs.getObject("fecha_hora_entrega", LocalDateTime.class));
        pedido.setNumeroMesa(rs.getInt("numero_mesa"));
        pedido.setIdResponsable(rs.getInt("id_responsable"));
        return pedido;
    }
}
