package ar.org.curso.centro8.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.curso.centro8.java.entities.Persona;
import ar.org.curso.centro8.java.enums.Rol;
import ar.org.curso.centro8.java.repositories.interfaces.I_PersonaRepository;

@Repository
public class PersonaRepository implements I_PersonaRepository{

    private final DataSource dataSource;

    public static final String SQL_CREATE = "INSERT INTO personas (nombre, apellido, rol) values (?,?,?)";
    public static final String SQL_FIND_BY_ID = "SELECT * FROM personas WHERE id_persona=?";
    public static final String SQL_FIND_ALL = "SELECT * FROM personas";
    public static final String SQL_UPDATE = "UPDATE personas SET nombre=?, apellido=?, rol=? where id_persona=?";
    public static final String SQL_DELETE = "DELETE FROM personas WHERE id_persona=?";
    public static final String SQL_FIND_BY_ROL = "SELECT * FROM personas WHERE rol=?";
    public static final String SQL_FIND_BY_NOMBRE = "SELECT * FROM personas WHERE nombre=?";
    public static final String SQL_FIND_BY_APELLIDO = "SELECT * FROM personas WHERE apellido=?";
    

    public PersonaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Persona persona) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, persona.getNombre());
            ps.setString(2, persona.getApellido());
            ps.setString(3, persona.getRol().name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    persona.setIdPersona(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Persona findById(int idPersona) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idPersona);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Persona> findAll() throws SQLException {
        List<Persona> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Persona persona) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, persona.getNombre());
            ps.setString(2, persona.getApellido());
            ps.setString(3, persona.getRol().name());
            ps.setInt(4, persona.getIdPersona());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int idPersona) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idPersona);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public List<Persona> findByRol(Rol rol) throws SQLException {
        List<Persona> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ROL)) {
            ps.setString(1, rol.name());
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public List<Persona> findByNombre(String nombre) throws SQLException {
        List<Persona> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE)) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public List<Persona> findByApellido(String apellido) throws SQLException {
        List<Persona> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_APELLIDO)) {
            ps.setString(1, apellido);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Persona mapRow(ResultSet rs) throws SQLException{
        Persona persona = new Persona();
        persona.setIdPersona(rs.getInt("id_persona"));
        persona.setNombre(rs.getString("nombre"));
        persona.setApellido(rs.getString("apellido"));
        persona.setRol(Rol.valueOf(rs.getString("rol")));
        return persona;
    }
}
