package ar.org.curso.centro8.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.curso.centro8.java.entities.Persona;
import ar.org.curso.centro8.java.enums.Rol;

public interface I_PersonaRepository {
    void create(Persona persona) throws SQLException;
    Persona findById(int idPersona) throws SQLException;
    List<Persona> findAll() throws SQLException;
    int update(Persona persona) throws SQLException;
    int delete(int idPersona) throws SQLException;
    List<Persona> findByRol(Rol rol) throws SQLException;
    List<Persona> findByNombre(String nombre) throws SQLException;
    List<Persona> findByApellido(String apellido) throws SQLException;
}
