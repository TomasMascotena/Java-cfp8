package ar.org.curso.centro8.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.curso.centro8.java.entities.DetallePedido;
import ar.org.curso.centro8.java.repositories.interfaces.I_DetallePedidoRepository;

@Repository
public class DetallePedidoRepository implements I_DetallePedidoRepository {

     private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES (?,?,?,?)";
    private static final String SQL_FIND_BY_ID_PEDIDO_AND_ID_PRODUCTO =
        "SELECT * FROM detalle_pedido WHERE id_pedido=? and id_producto=?";
    private static final String SQL_FIND_ALL = 
        "SELECT * FROM detalle_pedido";
    private static final String SQL_UPDATE =
        "UPDATE detalle_pedido SET cantidad=?, precio_unitario=? WHERE id_pedido=? and id_producto=?";
    private static final String SQL_DELETE = 
        "DELETE FROM detalle_pedido WHERE id_pedido=? and id_producto=?";
    private static final String SQL_FIND_BY_ID_PEDIDO =
        "SELECT * FROM detalle_pedido WHERE id_pedido=?";
    private static final String SQL_FIND_BY__ID_PRODUCTO =
        "SELECT * FROM detalle_pedido WHERE id_producto=?";
    
    public DetallePedidoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(DetallePedido detallePedido) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE)) {
            ps.setInt(1, detallePedido.getIdPedido());
            ps.setInt(2, detallePedido.getIdProducto());
            ps.setInt(3, detallePedido.getCantidad());
            ps.setDouble(4, detallePedido.getPrecioUnitario());
            ps.executeUpdate();
        }
    }
    
    @Override
    public DetallePedido findByIdPedidoAndIdProducto(int idPedido, int idProducto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_PEDIDO_AND_ID_PRODUCTO)) {
            ps.setInt(1, idPedido);
            ps.setInt(2, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<DetallePedido> findAll() throws SQLException {
        List<DetallePedido> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(DetallePedido detallePedido) throws SQLException {
        try(Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)){
            ps.setInt(1, detallePedido.getCantidad());
            ps.setDouble(2, detallePedido.getPrecioUnitario());
            ps.setInt(3, detallePedido.getIdPedido());
            ps.setInt(4, detallePedido.getIdProducto());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public int delete(int idPedido, int idProducto) throws SQLException {
        try(Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)){
                ps.setInt(1, idPedido);
                ps.setInt(2, idProducto);
                int filasAfectadas = ps.executeUpdate();
                return filasAfectadas;
            }    
    }


    @Override
    public List<DetallePedido> findByIdPedido(int idPedido) throws SQLException {
        List<DetallePedido> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_PEDIDO)){
            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }   
            }
        }
        return lista;
    }

    @Override
    public List<DetallePedido> findByIdProducto(int idProducto) throws SQLException {
        List<DetallePedido> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY__ID_PRODUCTO)){
            ps.setInt(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }   
            }
        }
        return lista;
    }

    private DetallePedido mapRow(ResultSet rs) throws SQLException{
        DetallePedido detallePedido = new DetallePedido();
        detallePedido.setIdPedido(rs.getInt("id_pedido"));
        detallePedido.setIdProducto(rs.getInt("id_producto"));
        detallePedido.setCantidad(rs.getInt("cantidad"));
        detallePedido.setPrecioUnitario(rs.getDouble("precio_unitario"));
        return detallePedido;
    }

}