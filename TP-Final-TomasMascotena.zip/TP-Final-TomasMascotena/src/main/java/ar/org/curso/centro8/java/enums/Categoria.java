package ar.org.curso.centro8.java.enums;

public enum Categoria {
    BEBIDAS_FRIAS, BEBIDAS_CALIENTES, COMIDAS , PASTELERIA;}
