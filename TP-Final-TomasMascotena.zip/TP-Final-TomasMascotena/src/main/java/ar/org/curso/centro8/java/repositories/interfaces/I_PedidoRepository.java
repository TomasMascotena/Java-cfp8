package ar.org.curso.centro8.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.curso.centro8.java.entities.Pedido;
import ar.org.curso.centro8.java.enums.TipoPedido;

public interface I_PedidoRepository {
    void create(Pedido pedido) throws SQLException;
    Pedido findById(int idPedido) throws SQLException;
    List<Pedido> findAll() throws SQLException;
    int update(Pedido pedido) throws SQLException;
    int delete(int idPedido) throws SQLException;
    List<Pedido> findByTipoPedido(TipoPedido tipoPedido) throws SQLException;
}