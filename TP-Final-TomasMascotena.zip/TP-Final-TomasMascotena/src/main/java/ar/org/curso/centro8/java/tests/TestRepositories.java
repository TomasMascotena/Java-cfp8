package ar.org.curso.centro8.java.tests;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.curso.centro8.java.entities.DetallePedido;
import ar.org.curso.centro8.java.entities.Pedido;
import ar.org.curso.centro8.java.entities.Persona;
import ar.org.curso.centro8.java.entities.Producto;
import ar.org.curso.centro8.java.enums.Categoria;
import ar.org.curso.centro8.java.enums.Estado;
import ar.org.curso.centro8.java.enums.Rol;
import ar.org.curso.centro8.java.enums.TipoPedido;
import ar.org.curso.centro8.java.repositories.DetallePedidoRepository;
import ar.org.curso.centro8.java.repositories.PedidoRepository;
import ar.org.curso.centro8.java.repositories.PersonaRepository;
import ar.org.curso.centro8.java.repositories.ProductoRepository;
import ar.org.curso.centro8.java.repositories.interfaces.I_DetallePedidoRepository;
import ar.org.curso.centro8.java.repositories.interfaces.I_PedidoRepository;
import ar.org.curso.centro8.java.repositories.interfaces.I_PersonaRepository;
import ar.org.curso.centro8.java.repositories.interfaces.I_ProductoRepository;

@SpringBootApplication(scanBasePackages = "ar.org.curso.centro8.java")
public class TestRepositories {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args);) {
           I_PersonaRepository personaRepository = context.getBean(PersonaRepository.class);
           I_ProductoRepository productoRepository = context.getBean(ProductoRepository.class);
           I_PedidoRepository pedidoRepository = context.getBean(PedidoRepository.class);
           I_DetallePedidoRepository detallePedidoRepository = context.getBean(DetallePedidoRepository.class);
           
            //Test 1: Crear una persona(empleado)
            System.out.println("\n>>> Test 1: creando una persona");
            Persona nuevaPersona = new Persona(0, "Julian", "Weich", Rol.CAJERO);
            personaRepository.create(nuevaPersona);
            if (nuevaPersona.getIdPersona()>0) {
                System.out.println(" ## Persona creada correctamente con id " + nuevaPersona.getIdPersona());
                System.out.println(nuevaPersona);
            }else {
                System.out.println(" ¡¡ ERROR - no se puedo crear la persona !!");
            }

            //Test 2: Buscar persona por ID
            System.out.println("\n>>> Test 2 buscando persona por ID " + nuevaPersona.getIdPersona() + " ...");
            Persona personaEncontrada = personaRepository.findById(nuevaPersona.getIdPersona());
            if (personaEncontrada!=null) {
                System.out.println(" ## Persona encontrada: " + personaEncontrada);
            }else{
                System.err.println(" ¡¡ ERROR - no se encontró la persona con el ID: " + nuevaPersona.getIdPersona());
            }

            //Test 3: Listar todas las personas
            System.out.println("\n>>> Test 3: listar todas las personas");
            List<Persona> personasTodas = personaRepository.findAll();
            if (!personasTodas.isEmpty()) {
                System.out.println(" ## Personas encontradas: " + personasTodas.size());
                personasTodas.forEach(System.out::println);
            } else {
                System.out.println(" !! ERROR - No se encontraron personas !!");
            }

            //Test 4: Actualizar una persona
            System.out.println("\n>>> Test 4: Actualizando persona " + nuevaPersona.getIdPersona() + "...");
            nuevaPersona.setNombre("Julian Juan");
            int filasPersonasAfectadas = personaRepository.update(nuevaPersona);
            if(filasPersonasAfectadas == 1){
                System.out.println(" ## Persona actualizada correctamente");
                System.out.println(" ## Verificando actualización: " + personaRepository.findById(nuevaPersona.getIdPersona()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar la persona !!");
            }

            //Test 5: Buscar por rol
            System.out.println("\n>>> Test 5: Buscando personas por rol CAJERO...");
            List<Persona> personasPorRol = personaRepository.findByRol(Rol.CAJERO);
            if(!personasPorRol.isEmpty()){
                System.out.println(" ## Personas con rol CAJERO encontradas: " + personasPorRol.size());
                personasPorRol.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron personas con ese rol !!");
            }

            //Test 6: Buscar por nombre
            System.out.println("\n>>> Test 6: Buscando personas por nombre 'Julian Juan'...");
            List<Persona> personasPorNombre = personaRepository.findByNombre("Julian Juan");
            if(!personasPorNombre.isEmpty()){
                System.out.println(" ## Personas encontradas: " + personasPorNombre.size());
                personasPorNombre.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron personas con ese nombre !!"); //modificar para que en vez de buscar nombre pueda contener letras de el
            }

            //Test 7: Buscar por apellido
            System.out.println("\n>>> Test 7: Buscando personas por apellido 'Weich'...");
            List<Persona> personasPorApellido = personaRepository.findByApellido("Weich");
            if(!personasPorApellido.isEmpty()){
                System.out.println(" ## Personas encontradas: " + personasPorApellido.size());
                personasPorApellido.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron personas con ese apellido !!");
            }

            //Test 8: Crear un nuevo producto
            System.out.println("\n>>> Test 8: Creando un producto");
            Producto nuevoProducto = new Producto(0, "Cafe doble", 1200.0, Categoria.BEBIDAS_CALIENTES);
            productoRepository.create(nuevoProducto);
            if(nuevoProducto.getIdProducto() > 0){
                System.out.println(" ## Producto creado correctamente con id " + nuevoProducto.getIdProducto());
                System.out.println(nuevoProducto);
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el producto !!");
            }

            //Test 9: Buscar producto por ID
            System.out.println("\n>>> Test 9: Buscando producto por ID " + nuevoProducto.getIdProducto() + "...");
            Producto productoEncontrado = productoRepository.findById(nuevoProducto.getIdProducto());
            if(productoEncontrado != null){
                System.out.println(" ## Producto encontrado: " + productoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró el producto !!");
            }

            //Test 10: Actualizar un producto
            System.out.println("\n>>> Test 10: Actualizando producto " + nuevoProducto.getIdProducto() + "...");
            nuevoProducto.setPrecio(1400.0);
            int filasProductosAfectados = productoRepository.update(nuevoProducto);
            if(filasProductosAfectados == 1){
                System.out.println(" ## Producto actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + productoRepository.findById(nuevoProducto.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar el producto !!");
            }

            //Test 11: Listar todos los productos
            System.out.println("\n>>> Test 11: Listando todos los productos...");
            List<Producto> listaProductos = productoRepository.findAll();
            if(!listaProductos.isEmpty()){
                System.out.println(" ## Productos encontrados: " + listaProductos.size());
                listaProductos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron productos !!");
            }

            //Test 12: Buscar productos por categoría
            System.out.println("\n>>> Test 12: Buscando productos por categoría BEBIDAS_CALIENTES...");
            List<Producto> productosBebidasCalientes = productoRepository.findByCategoria(Categoria.BEBIDAS_CALIENTES);
            if(!productosBebidasCalientes.isEmpty()){
                System.out.println(" ## Productos encontrados: " + productosBebidasCalientes.size());
                productosBebidasCalientes.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron productos con esa categoría !!");
            }

            //Test 13: Eliminar un producto
            System.out.println("\n>>> Test 13: Eliminando producto con ID " + nuevoProducto.getIdProducto() + "...");
            int filasEliminadas = productoRepository.delete(nuevoProducto.getIdProducto());
            if(filasEliminadas == 1){
                System.out.println(" ## Producto eliminado correctamente");
                System.out.println(" ## Verificando eliminación: " + productoRepository.findById(nuevoProducto.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar el producto !!");
            }

            //Test 14: Crear un pedido nuevo
            System.out.println("\n>>> Test 14: Creando un pedido");
            Pedido nuevoPedido = new Pedido(0, TipoPedido.EN_MESA, Estado.EN_PROCESO, true, 38000.00, LocalDateTime.now(), null, 4, 2);
            pedidoRepository.create(nuevoPedido);
            if (nuevoPedido.getIdPedido() > 0) {
                System.out.println(" ## Pedido creado correctamente con id " + nuevoPedido.getIdPedido());
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el pedido !!");
            }

            //Test 15: Crear detallePedido nuevos
            System.out.println("\n>>> Test 15: Creando detalles de pedidos");
            DetallePedido nuevoDetallePedidoComida = new DetallePedido(nuevoPedido.getIdPedido(), 16, 2, 18000.00);
            detallePedidoRepository.create(nuevoDetallePedidoComida);
            if (nuevoDetallePedidoComida.getIdPedido() > 0) {
                System.out.println(" ## Detalle de pedido creado correctamente con id de pedido " + nuevoDetallePedidoComida.getIdPedido() + " e id de producto " + nuevoDetallePedidoComida.getIdProducto());
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el detalle de pedido !!");
            }

            DetallePedido nuevoDetallePedidoBebida = new DetallePedido(nuevoPedido.getIdPedido(), 7, 2, 1000.00);
            detallePedidoRepository.create(nuevoDetallePedidoBebida);
            if (nuevoDetallePedidoBebida.getIdPedido() > 0) {
                System.out.println(" ## Detalle de pedido creado correctamente con id de pedido " + nuevoDetallePedidoBebida.getIdPedido() + " e id de producto " + nuevoDetallePedidoBebida.getIdProducto());
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el detalle de pedido !!");
            }

            //Test 16: Buscar pedido por ID
            System.out.println("\n>>> Test 16: Buscando pedido por ID " + nuevoPedido.getIdPedido() + "...");
            Pedido pedidoEncontrado = pedidoRepository.findById(nuevoPedido.getIdPedido());
            if(pedidoEncontrado != null){
                System.out.println(" ## Pedido encontrado: " + pedidoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró el Pedido !!");
            }

            //Test 17: Actualizar un pedido
            System.out.println("\n>>> Test 17: Actualizando pedido " + nuevoPedido.getIdPedido() + "...");
            nuevoPedido.setMontoTotal(39000.00);
            int filasPedidosAfectados = pedidoRepository.update(nuevoPedido);
            if(filasPedidosAfectados == 1){
                System.out.println(" ## Pedido actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + pedidoRepository.findById(nuevoPedido.getIdPedido()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar el pedido !!");
            }

            //Test 18: Actualizar un detallePedido
            System.out.println("\n>>> Test 18: Actualizando detalle de pedido con id de pedido " + nuevoDetallePedidoBebida.getIdPedido() + " e id de producto " + nuevoDetallePedidoBebida.getIdProducto() + "...");
            nuevoDetallePedidoBebida.setCantidad(3);
            int filasDetallePedidoAfectadas = detallePedidoRepository.update(nuevoDetallePedidoBebida);
            if(filasDetallePedidoAfectadas == 1){
                System.out.println(" ## Detalle de pedido actualizado correctamente");
                System.out.println(" ## Verificando actualización id pedido: " + detallePedidoRepository.findByIdPedido(nuevoDetallePedidoBebida.getIdPedido()) + " e id producto: "+ detallePedidoRepository.findByIdProducto(nuevoDetallePedidoBebida.getIdProducto()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar el pedido !!");
            }

            //Test 19: Listar todos los pedidos
            System.out.println("\n>>> Test 19: Listando todos los pedidos...");
            List<Pedido> listaPedidos = pedidoRepository.findAll();
            if(!listaPedidos.isEmpty()){
                System.out.println(" ## Pedidos encontrados: " + listaPedidos.size());
                listaPedidos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron pedidos !!");
            }

            //Test 20: Buscar pedidos por tipo de pedido
            System.out.println("\n>>> Test 20: Buscando productos por tipo de pedido");
            List<Pedido> pedidosEnMesa = pedidoRepository.findByTipoPedido(TipoPedido.EN_MESA);
            if(!pedidosEnMesa.isEmpty()){
                System.out.println(" ## Pedidos encontrados: " + pedidosEnMesa.size());
                pedidosEnMesa.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron pedidos en mesa !!");
            }

            //Test 21: Listar todos los detalle pedidos
            System.out.println("\n>>> Test 21: Listando todos los detalle pedidos...");
            List<DetallePedido> listaDetallePedidos = detallePedidoRepository.findAll();
            if(!listaDetallePedidos.isEmpty()){
                System.out.println(" ## Detalle pedidos encontrados: " + listaDetallePedidos.size());
                listaDetallePedidos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron detalle pedidos !!");
            }

            //Test 22: Buscar detalle pedido por ID pedido
            System.out.println("\n>>> Test 22: Buscando detallePedidos por ID pedido: " + nuevoDetallePedidoBebida.getIdPedido() + "...");
            List<DetallePedido> listaDetallePedidosIdPedidos = detallePedidoRepository.findByIdPedido(nuevoPedido.getIdPedido());
            if(!listaDetallePedidosIdPedidos.isEmpty()){
                System.out.println(" ## DetallePedidos con el id pedido " + nuevoPedido.getIdPedido() + " encontrados: " + listaDetallePedidosIdPedidos.size());
                listaDetallePedidosIdPedidos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron detallePedidos !!");
            }

            //Test 23: Buscar detalle pedido por ID producto
            System.out.println("\n>>> Test 23: Buscando detallePedidos por ID producto: " + nuevoDetallePedidoBebida.getIdProducto() + "...");
            List<DetallePedido> listaDetallePedidosIdProductos = detallePedidoRepository.findByIdProducto(nuevoDetallePedidoBebida.getIdProducto());
            if(!listaDetallePedidosIdProductos.isEmpty()){
                System.out.println(" ## DetallePedidos con el id producto " + nuevoDetallePedidoBebida.getIdProducto() + " encontrados: " + listaDetallePedidosIdProductos.size());
                listaDetallePedidosIdProductos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron detallePedidos !!");
            }

            //Test 24: Eliminar detalle pedido
            System.out.println("\n>>> Test 24: Eliminando detalle pedido con id de pedido " + nuevoDetallePedidoBebida.getIdPedido() + " e id de producto " + nuevoDetallePedidoBebida.getIdProducto() + "...");
            int filasDetallePedidoEliminadas = detallePedidoRepository.delete(nuevoDetallePedidoBebida.getIdPedido(), nuevoDetallePedidoBebida.getIdProducto());
            if(filasDetallePedidoEliminadas == 1){
                System.out.println(" ## Detalle pedido eliminado correctamente");
                System.out.println(" ## Verificando eliminación: " + detallePedidoRepository.findByIdPedido(nuevoDetallePedidoBebida.getIdPedido()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar el detalle pedido !!");
            }

            System.out.println("\n>>> Test 25: Eliminando detalle pedido con id de pedido " + nuevoDetallePedidoComida.getIdPedido() + " e id de producto " + nuevoDetallePedidoComida.getIdProducto() + "...");
            int filasDetallePedidoEliminadasComida = detallePedidoRepository.delete(nuevoDetallePedidoComida.getIdPedido(), nuevoDetallePedidoComida.getIdProducto());
            if(filasDetallePedidoEliminadasComida == 1){
                System.out.println(" ## Detalle pedido eliminado correctamente");
                System.out.println(" ## Verificando eliminación: " + detallePedidoRepository.findByIdPedido(nuevoDetallePedidoComida.getIdPedido()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar el detalle pedido !!");
            }

            //Test 26: Eliminar un pedido
            System.out.println("\n>>> Test 26: Eliminando pedido con ID " + nuevoPedido.getIdPedido() + "...");
            int filasPedidosEliminados = pedidoRepository.delete(nuevoPedido.getIdPedido());
            if(filasPedidosEliminados == 1){
                System.out.println(" ## Pedido eliminado correctamente");
                System.out.println(" ## Verificando eliminación: " + pedidoRepository.findById(nuevoPedido.getIdPedido()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar el pedido !!");
            }

        
        } catch (Exception e) {
            System.err.println("¡¡ ERROR EN LA BASE DE DATOS !!");
            e.printStackTrace();
        } finally {
            System.out.println("<<< Pruebas finalizadas >>>");
            System.out.println("<<< Contexto de Spring cerrado >>>");
        }
    }
}
